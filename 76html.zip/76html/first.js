<script>
document.getElementById("demo").innerHTML="My First javascript"
</script>